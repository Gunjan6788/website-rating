var btn = document.getElementById("goback")

    btn.addEventListener("click",function(){
    window.location.href="/popup.html"
})